import { Download, ShieldAlert, Sparkles, X, Zap } from 'lucide-react';
import { TABS } from '../lib/constants';
import { cn, formatMoney } from '../lib/utils';

export const SectionTitle = ({ eyebrow, title, subtitle, action }) => (
  <div className="mb-4 flex items-start justify-between gap-4">
    <div>
      {eyebrow && <p className="mb-1 text-[11px] font-bold uppercase tracking-[0.22em] text-synox-600">{eyebrow}</p>}
      <h2 className="text-xl font-bold text-slate-900">{title}</h2>
      {subtitle && <p className="mt-1 text-sm text-slate-500">{subtitle}</p>}
    </div>
    {action}
  </div>
);

export const BlobHeader = ({ title, subtitle, right }) => (
  <div className="synox-gradient relative overflow-hidden rounded-b-[40px] px-5 pb-7 pt-14 shadow-synox">
    <div className="absolute -right-16 -top-16 h-60 w-60 rounded-full bg-[radial-gradient(circle,#B49FFF,#C4B5FD)] opacity-55" />
    <div className="absolute right-14 top-2 h-24 w-24 rounded-full bg-[radial-gradient(circle,#7C3AED,#A78BFA)] opacity-25" />
    <div className="relative z-10 flex items-start justify-between gap-4">
      <div>
        <div className="mb-2 inline-flex items-center gap-2 rounded-full bg-white/70 px-3 py-1 text-[11px] font-semibold text-synox-700 backdrop-blur">
          <Zap className="h-3.5 w-3.5" />
          SYNOX TRADE™
        </div>
        <h1 className="font-display text-2xl font-black text-slate-900">{title}</h1>
        {subtitle && <p className="mt-2 max-w-[28rem] text-sm text-slate-600">{subtitle}</p>}
      </div>
      {right}
    </div>
  </div>
);

export const Card = ({ className, children }) => <div className={cn('synox-card p-4', className)}>{children}</div>;

export const MetricCard = ({ label, value, tone = 'neutral', icon }) => {
  const tones = {
    neutral: 'from-white to-slate-50 text-slate-900',
    green: 'from-emerald-50 to-white text-emerald-700',
    red: 'from-rose-50 to-white text-rose-700',
    purple: 'from-synox-50 to-white text-synox-700',
  };

  return (
    <div className={cn('rounded-3xl border border-white/80 bg-gradient-to-br p-4 shadow-soft', tones[tone])}>
      <div className="mb-3 flex items-center justify-between">
        <span className="text-xs font-semibold uppercase tracking-[0.16em] text-slate-500">{label}</span>
        {icon}
      </div>
      <div className="font-display text-2xl font-black">{value}</div>
    </div>
  );
};

export const Badge = ({ children, color = 'purple' }) => {
  const styles = {
    purple: 'bg-synox-100 text-synox-700',
    green: 'bg-emerald-100 text-emerald-700',
    red: 'bg-rose-100 text-rose-700',
    amber: 'bg-amber-100 text-amber-700',
    slate: 'bg-slate-100 text-slate-700',
  };
  return <span className={cn('synox-pill', styles[color])}>{children}</span>;
};

export const FooterDisclaimer = () => (
  <p className="mt-6 px-4 pb-28 text-center text-[10px] text-slate-400">
    ⚠️ SYNOX TRADE™ · Outil d'aide à la décision · Le trading comporte des risques élevés · Broker : Exness · MT4
  </p>
);

export const Toast = ({ toast, onClose }) => {
  if (!toast) return null;

  return (
    <div className="fixed left-1/2 top-4 z-50 w-[calc(100%-24px)] max-w-md -translate-x-1/2 rounded-2xl border border-white/60 bg-slate-900 px-4 py-3 text-sm text-white shadow-2xl">
      <div className="flex items-start gap-3">
        <div className={cn('mt-0.5 rounded-full p-1', toast.type === 'success' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-rose-500/20 text-rose-300')}>
          {toast.type === 'success' ? <Sparkles className="h-4 w-4" /> : <ShieldAlert className="h-4 w-4" />}
        </div>
        <p className="flex-1 leading-relaxed">{toast.message}</p>
        <button onClick={onClose} className="text-white/70 transition hover:text-white">
          <X className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
};

export const BottomNav = ({ activeTab, onChange }) => (
  <div className="fixed bottom-0 left-1/2 z-40 w-full max-w-xl -translate-x-1/2 border-t border-white/70 bg-white/90 px-2 py-3 backdrop-blur-xl">
    <div className="grid grid-cols-5 gap-1">
      {TABS.map((tab) => {
        const active = tab.id === activeTab;
        return (
          <button
            key={tab.id}
            onClick={() => onChange(tab.id)}
            className={cn(
              'flex flex-col items-center gap-1 rounded-2xl px-2 py-2 text-[11px] font-semibold transition',
              active ? 'bg-synox-100 text-synox-700' : 'text-slate-500 hover:bg-slate-50',
            )}
          >
            <span className="text-lg leading-none">{tab.emoji}</span>
            {tab.label}
          </button>
        );
      })}
    </div>
  </div>
);

export const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-2xl border border-white/70 bg-white px-3 py-2 text-xs shadow-soft">
      <div className="font-semibold text-slate-700">{label}</div>
      <div className="mt-1 text-slate-500">{formatMoney(payload[0].value)}</div>
    </div>
  );
};

export const InstallBanner = ({ visible, onInstall, onDismiss }) => {
  if (!visible) return null;
  return (
    <div className="mx-4 mt-4 rounded-3xl border border-synox-200 bg-white/90 p-4 shadow-soft backdrop-blur">
      <div className="flex items-start gap-3">
        <div className="rounded-2xl bg-synox-100 p-3 text-synox-700">
          <Download className="h-5 w-5" />
        </div>
        <div className="min-w-0 flex-1">
          <div className="font-semibold text-slate-900">Installer SYNOX sur Android</div>
          <p className="mt-1 text-sm text-slate-500">Ajoute l’application à l’écran d’accueil pour un accès rapide en mode PWA.</p>
          <div className="mt-3 flex gap-2">
            <button className="synox-button" onClick={onInstall}>Installer</button>
            <button className="synox-button-secondary" onClick={onDismiss}>Plus tard</button>
          </div>
        </div>
      </div>
    </div>
  );
};
