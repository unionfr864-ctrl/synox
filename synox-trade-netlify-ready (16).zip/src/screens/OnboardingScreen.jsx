import { useMemo, useState } from 'react';
import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { LoaderCircle, Zap } from 'lucide-react';
import { getOnboardingProjection } from '../lib/api';
import { buildProjectionChart, formatMoney } from '../lib/utils';
import { Badge, BlobHeader, Card, CustomTooltip, FooterDisclaimer, SectionTitle } from '../components/common';

export default function OnboardingScreen({ state, onProjectionSave, onFinish, showToast }) {
  const [capital, setCapital] = useState(state.capital || 10);
  const [loading, setLoading] = useState(false);
  const [projection, setProjection] = useState(state.projection || null);

  const chartData = useMemo(() => buildProjectionChart(capital, projection), [capital, projection]);

  const handleProjection = async () => {
    const numericCapital = Number(capital);
    if (!numericCapital || numericCapital < 1) {
      showToast('Entre un capital valide supérieur ou égal à 1$.');
      return;
    }

    setLoading(true);
    try {
      const result = await getOnboardingProjection(numericCapital);
      setProjection(result);
      onProjectionSave(numericCapital, result);
      showToast('Projection générée avec succès.', 'success');
    } catch (error) {
      showToast(error.message || 'Impossible de générer la projection.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#F4F2FF] pb-10">
      <BlobHeader title="Votre IA trader institutionnel" subtitle="SMC + ICT · Projections de capital · Signaux intelligents" />
      <div className="mx-auto -mt-8 flex w-full max-w-xl flex-col gap-4 px-4">
        <Card className="p-6">
          <div className="mb-6 text-center">
            <div className="font-display text-3xl font-black text-slate-900">⚡ SYNOX TRADE™</div>
            <p className="mt-2 text-sm text-slate-500">Votre IA trader institutionnel · SMC + ICT</p>
          </div>

          <label className="synox-label">Votre capital de départ ($)</label>
          <input type="number" min="1" className="synox-input" placeholder="ex : 10" value={capital} onChange={(event) => setCapital(event.target.value)} />
          <p className="mt-3 text-sm text-slate-500">
            SYNOX TRADE™ gère tout le reste. Stratégie, analyse, signaux — tout est automatique.
          </p>

          <button className="synox-button mt-5 w-full" onClick={handleProjection} disabled={loading}>
            {loading ? <LoaderCircle className="h-4 w-4 animate-spin" /> : <Zap className="h-4 w-4" />}
            Confier mon capital à SYNOX →
          </button>
        </Card>

        {projection && (
          <>
            <Card className="bg-gradient-to-br from-emerald-50 to-white p-6">
              <p className="text-xs font-semibold uppercase tracking-[0.18em] text-emerald-700">Projection mensuelle</p>
              <h2 className="mt-2 text-3xl font-black text-emerald-700">
                {formatMoney(projection.monthly_low)} — {formatMoney(projection.monthly_high)}
              </h2>
              <p className="mt-2 text-sm text-slate-600">Potentiel ce mois</p>
              <div className="mt-4 h-56">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={chartData}>
                    <defs>
                      <linearGradient id="projectionGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#10B981" stopOpacity={0.35} />
                        <stop offset="95%" stopColor="#10B981" stopOpacity={0.03} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
                    <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                    <YAxis tickFormatter={(value) => `$${value}`} tick={{ fontSize: 12 }} width={54} />
                    <Tooltip content={<CustomTooltip />} />
                    <Area type="monotone" dataKey="value" stroke="#10B981" fillOpacity={1} fill="url(#projectionGradient)" strokeWidth={3} />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </Card>

            <Card>
              <SectionTitle eyebrow="Plan personnalisé" title="Contexte du jour" />
              <div className="grid gap-3 md:grid-cols-2">
                <div className="rounded-2xl bg-synox-50 p-4">
                  <p className="text-xs font-semibold uppercase tracking-[0.16em] text-synox-700">Meilleures paires</p>
                  <div className="mt-3 flex flex-wrap gap-2">
                    {(projection.best_pairs || []).map((pair) => <Badge key={pair}>{pair}</Badge>)}
                  </div>
                </div>
                <div className="rounded-2xl bg-amber-50 p-4">
                  <p className="text-xs font-semibold uppercase tracking-[0.16em] text-amber-700">Meilleure session</p>
                  <p className="mt-3 text-sm font-semibold text-slate-900">{projection.best_session}</p>
                  <p className="mt-1 text-xs text-slate-500">Objectif journalier : {formatMoney(projection.daily_goal)}</p>
                </div>
              </div>
              <p className="mt-4 text-sm leading-relaxed text-slate-600">{projection.context}</p>
              <div className="mt-4 rounded-2xl bg-slate-50 p-4 text-sm text-slate-700">{projection.plan}</div>
              <button className="synox-button mt-5 w-full" onClick={() => onFinish(Number(capital))}>Démarrer avec SYNOX →</button>
            </Card>
          </>
        )}
      </div>
      <FooterDisclaimer />
    </div>
  );
}
