import { useEffect, useRef, useState } from 'react';
import { LoaderCircle, RefreshCw, Wifi } from 'lucide-react';
import { SYNOX_SOURCES } from '../lib/constants';
import { isCacheFresh } from '../lib/utils';
import { getSignals as getSignalsApi } from '../lib/api';
import { Badge, BlobHeader, Card, FooterDisclaimer, SectionTitle } from '../components/common';

export default function SignalsScreen({ state, onSignalsSave, showToast }) {
  const [phase, setPhase] = useState('idle');
  const [visibleCount, setVisibleCount] = useState(0);
  const [result, setResult] = useState(state.lastSignals || null);
  const [error, setError] = useState('');
  const intervalRef = useRef(null);

  useEffect(() => {
    setResult(state.lastSignals || null);
  }, [state.lastSignals]);

  useEffect(() => () => {
    if (intervalRef.current) clearInterval(intervalRef.current);
  }, []);

  const cachedFresh = isCacheFresh(state.signalsTimestamp, 2);

  const startAnimation = () => {
    setVisibleCount(0);
    if (intervalRef.current) clearInterval(intervalRef.current);
    intervalRef.current = setInterval(() => {
      setVisibleCount((prev) => {
        const next = prev + 1;
        if (next >= SYNOX_SOURCES.length) {
          clearInterval(intervalRef.current);
          return SYNOX_SOURCES.length;
        }
        return next;
      });
    }, 1100);
  };

  const handleGetSignals = async ({ force = false } = {}) => {
    if (cachedFresh && !force && state.lastSignals) {
      setResult(state.lastSignals);
      setPhase('done');
      showToast('Signaux chargés depuis le cache 2h.', 'success');
      return;
    }

    setPhase('loading');
    setError('');
    startAnimation();
    const startTime = Date.now();

    try {
      const response = await Promise.race([
        getSignalsApi(),
        new Promise((_, reject) => setTimeout(() => reject(new Error('timeout')), 30000)),
      ]);

      const elapsed = Date.now() - startTime;
      const minWait = SYNOX_SOURCES.length * 1100 * 0.8;
      if (elapsed < minWait) {
        await new Promise((resolve) => setTimeout(resolve, minWait - elapsed));
      }

      if (intervalRef.current) clearInterval(intervalRef.current);
      setVisibleCount(SYNOX_SOURCES.length);
      setResult(response);
      onSignalsSave(response);
      setPhase('done');
      showToast('Briefing SYNOX prêt.', 'success');
    } catch (err) {
      if (intervalRef.current) clearInterval(intervalRef.current);
      setError(err.message === 'timeout' ? 'Temps limite atteint. Réessaie dans quelques instants.' : err.message);
      setPhase('done');
      showToast(err.message === 'timeout' ? 'Les signaux ont dépassé 30 secondes.' : err.message);
    }
  };

  return (
    <div>
      <BlobHeader
        title="Signaux"
        subtitle="Veille multi-sources, contexte macro et top opportunités SYNOX avec cache 2h."
        right={<button className="rounded-2xl bg-white/80 p-3 text-synox-700 shadow-soft" onClick={() => handleGetSignals({ force: true })}><RefreshCw className="h-5 w-5" /></button>}
      />
      <div className="mx-auto -mt-8 flex max-w-xl flex-col gap-4 px-4">
        <Card>
          <SectionTitle
            eyebrow="Mode radar"
            title="Recherche institutionnelle"
            subtitle={cachedFresh ? 'Cache actif : moins de 2h.' : 'Aucun cache frais disponible.'}
            action={<button className="synox-button" onClick={() => handleGetSignals()} disabled={phase === 'loading'}>{phase === 'loading' ? <LoaderCircle className="h-4 w-4 animate-spin" /> : <Wifi className="h-4 w-4" />}Lancer SYNOX</button>}
          />

          {phase === 'loading' && (
            <div className="space-y-2">
              {SYNOX_SOURCES.slice(0, visibleCount).map((source, index) => (
                <div key={`${source.name}-${index}`} className="flex items-center gap-3 rounded-2xl bg-slate-50 px-4 py-3 text-sm">
                  <span className="text-lg">{source.icon}</span>
                  <div className="min-w-0 flex-1">
                    <div className="font-semibold text-slate-900">{source.name}</div>
                    <div className="truncate text-xs text-slate-500">{source.url}</div>
                  </div>
                  <Badge color="purple">{source.type}</Badge>
                </div>
              ))}
            </div>
          )}

          {error && <div className="rounded-2xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700">{error}</div>}
        </Card>

        {result && (
          <>
            <Card>
              <SectionTitle eyebrow="Briefing" title="SYNOX du jour" subtitle={`Snapshot UTC : ${result.timestamp || '—'}`} />
              <p className="text-sm leading-relaxed text-slate-700">{result.synox_briefing}</p>
              <div className="mt-4 flex flex-wrap gap-2">
                <Badge color="purple">USD Bias: {result.daily_bias_usd}</Badge>
                <Badge color="amber">{result.market_regime}</Badge>
                <Badge color="slate">Volatilité: {result.volatility}</Badge>
                <Badge color="green">DXY {result.dxy?.change_pct}</Badge>
              </div>
            </Card>

            <Card className={`border-2 ${result.top_signal?.direction === 'BUY' ? 'border-emerald-200 bg-gradient-to-br from-emerald-50 to-white' : 'border-rose-200 bg-gradient-to-br from-rose-50 to-white'}`}>
              <SectionTitle eyebrow="Top signal" title={`${result.top_signal?.direction === 'BUY' ? '🟢' : '🔴'} ${result.top_signal?.pair || '—'}`} subtitle={result.top_signal?.reason} />
              <div className="grid grid-cols-2 gap-3 text-sm">
                <Card className="bg-white/70"><div className="text-xs uppercase tracking-[0.16em] text-slate-500">Entrée</div><div className="mt-2 font-bold text-slate-900">{result.top_signal?.entry}</div></Card>
                <Card className="bg-white/70"><div className="text-xs uppercase tracking-[0.16em] text-slate-500">Confiance</div><div className="mt-2 font-bold text-slate-900">{result.top_signal?.confidence}%</div></Card>
                <Card className="bg-white/70"><div className="text-xs uppercase tracking-[0.16em] text-slate-500">TP1 / TP2</div><div className="mt-2 font-bold text-slate-900">{result.top_signal?.tp1} · {result.top_signal?.tp2}</div></Card>
                <Card className="bg-white/70"><div className="text-xs uppercase tracking-[0.16em] text-slate-500">SL / RR</div><div className="mt-2 font-bold text-slate-900">{result.top_signal?.sl} · {result.top_signal?.rr}</div></Card>
              </div>
              <div className="mt-4 flex flex-wrap gap-2">{(result.top_signal?.confluences || []).map((item) => <Badge key={item}>{item}</Badge>)}</div>
            </Card>

            <Card>
              <SectionTitle eyebrow="Contexte macro" title="Faits & liquidité" />
              <div className="space-y-3 text-sm text-slate-700">
                <div className="rounded-2xl bg-slate-50 p-4"><strong>Phase Power of 3 :</strong> {result.power_of_3_phase}</div>
                <div className="rounded-2xl bg-slate-50 p-4"><strong>Prochaine killzone :</strong> {result.next_killzone}</div>
                <div className="rounded-2xl bg-slate-50 p-4"><strong>Cible liquidité :</strong> {result.liquidity_target}</div>
                <ul className="space-y-2 rounded-2xl bg-slate-50 p-4">{(result.macro_facts || []).map((fact) => <li key={fact}>• {fact}</li>)}</ul>
              </div>
            </Card>

            <Card>
              <SectionTitle eyebrow="Signaux" title="Opportunités complémentaires" />
              <div className="space-y-3">
                {(result.signals || []).map((signal, index) => (
                  <div key={`${signal.pair}-${index}`} className="rounded-2xl bg-slate-50 p-4">
                    <div className="flex items-center justify-between gap-3">
                      <div>
                        <div className="font-semibold text-slate-900">{signal.pair}</div>
                        <div className="text-sm text-slate-500">{signal.reason}</div>
                      </div>
                      <Badge color={signal.direction === 'BUY' ? 'green' : 'red'}>{signal.direction}</Badge>
                    </div>
                    <div className="mt-3 grid grid-cols-2 gap-3 text-sm text-slate-700">
                      <div>Entrée : <strong>{signal.entry}</strong></div>
                      <div>TP : <strong>{signal.tp}</strong></div>
                      <div>SL : <strong>{signal.sl}</strong></div>
                      <div>RR : <strong>{signal.rr}</strong></div>
                      <div>Risque : <strong>{signal.risk}</strong></div>
                      <div>Timing : <strong>{signal.timing}</strong></div>
                    </div>
                    <div className="mt-3 flex flex-wrap gap-2">{(signal.confluences || []).map((item) => <Badge key={item}>{item}</Badge>)}</div>
                  </div>
                ))}
              </div>
            </Card>

            <Card>
              <SectionTitle eyebrow="À éviter" title="Paires à éviter" />
              <div className="space-y-2 text-sm">{(result.pairs_to_avoid || []).map((pair) => <div key={pair.pair} className="rounded-2xl bg-rose-50 p-4 text-rose-700"><strong>{pair.pair}</strong> — {pair.reason}</div>)}</div>
            </Card>

            <Card>
              <SectionTitle eyebrow="Calendrier" title="Prochains événements" />
              <div className="space-y-3">
                {(result.calendar || []).map((event, index) => (
                  <div key={`${event.time_utc}-${index}`} className="rounded-2xl bg-slate-50 p-4 text-sm text-slate-700">
                    <div className="flex items-center justify-between gap-3">
                      <div className="font-semibold text-slate-900">{event.time_utc} · {event.event}</div>
                      <Badge color={event.impact === 'FORT' ? 'red' : event.impact === 'MOYEN' ? 'amber' : 'slate'}>{event.impact}</Badge>
                    </div>
                    <div className="mt-2 text-xs text-slate-500">{event.currency} · Forecast {event.forecast} · Previous {event.previous}</div>
                    <div className="mt-2">{event.advice}</div>
                  </div>
                ))}
              </div>
            </Card>

            <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
              <Card>
                <SectionTitle eyebrow="Risk management" title="Cadre du jour" />
                <div className="space-y-2 text-sm text-slate-700">
                  <div>Max trades aujourd’hui : <strong>{result.risk_management?.max_trades_today}</strong></div>
                  <div>Lot 10$ : <strong>{result.risk_management?.lot_10usd}</strong></div>
                  <div>Perte max du jour : <strong>{result.risk_management?.max_loss_today}</strong></div>
                </div>
              </Card>
              <Card>
                <SectionTitle eyebrow="Conseil" title="Daily tip" />
                <p className="text-sm text-slate-700">{result.daily_tip}</p>
              </Card>
            </div>
          </>
        )}
      </div>
      <FooterDisclaimer />
    </div>
  );
}
