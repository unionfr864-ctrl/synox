import { useEffect, useMemo, useState } from 'react';
import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { BarChart3, BookOpenText, LoaderCircle, TrendingUp, Wallet } from 'lucide-react';
import { DAILY_ADVICE_CACHE_KEY, MARKETS, PAIRS } from '../lib/constants';
import {
  computeTradeStats,
  formatMoney,
  formatNumber,
  getCapitalSeries,
  getCurrentCapital,
  getMarketStatus,
  getProgressionMessage,
  isCacheFresh,
  todayInputValue,
  uid,
} from '../lib/utils';
import { getDailyAdvice } from '../lib/api';
import { BlobHeader, Card, CustomTooltip, FooterDisclaimer, MetricCard, SectionTitle } from '../components/common';

export default function HomeScreen({ state, onAddTrade, showToast }) {
  const [now, setNow] = useState(new Date());
  const [dailyAdvice, setDailyAdvice] = useState('');
  const [adviceLoading, setAdviceLoading] = useState(false);
  const [form, setForm] = useState({
    date: todayInputValue(),
    pair: 'EUR/USD',
    direction: 'BUY',
    result: '',
    notes: '',
  });

  useEffect(() => {
    const timer = setInterval(() => setNow(new Date()), 60_000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    const cachedRaw = localStorage.getItem(DAILY_ADVICE_CACHE_KEY);
    if (cachedRaw) {
      try {
        const cached = JSON.parse(cachedRaw);
        if (isCacheFresh(cached.timestamp, 24)) {
          setDailyAdvice(cached.value);
          return;
        }
      } catch {
        // ignore broken cache
      }
    }

    let cancelled = false;
    const loadAdvice = async () => {
      setAdviceLoading(true);
      try {
        const advice = await getDailyAdvice();
        if (cancelled) return;
        setDailyAdvice(advice);
        localStorage.setItem(DAILY_ADVICE_CACHE_KEY, JSON.stringify({ value: advice, timestamp: Date.now() }));
      } catch {
        if (!cancelled) setDailyAdvice('Configure ta clé API pour afficher le conseil automatique SYNOX du jour.');
      } finally {
        if (!cancelled) setAdviceLoading(false);
      }
    };

    loadAdvice();
    return () => {
      cancelled = true;
    };
  }, []);

  const marketStatuses = useMemo(() => MARKETS.map((market) => ({ ...market, ...getMarketStatus(market, now) })), [now]);
  const londonOpen = marketStatuses.find((market) => market.name === 'Londres')?.isOpen;
  const newYorkOpen = marketStatuses.find((market) => market.name === 'New York')?.isOpen;
  const overlap = londonOpen && newYorkOpen;

  const stats = useMemo(() => computeTradeStats(state.trades), [state.trades]);
  const currentCapital = useMemo(() => getCurrentCapital(state), [state]);
  const capitalSeries = useMemo(() => getCapitalSeries(state), [state]);

  const submitTrade = () => {
    const result = Number(form.result);
    if (!form.pair || Number.isNaN(result)) {
      showToast('Renseigne la paire et le résultat du trade.');
      return;
    }

    onAddTrade({
      id: uid(),
      date: form.date,
      pair: form.pair,
      direction: form.direction,
      lot: '',
      entry: '',
      tp: '',
      sl: '',
      result,
      notes: form.notes,
      source: 'home',
    });

    setForm({ date: todayInputValue(), pair: form.pair, direction: form.direction, result: '', notes: '' });
    showToast('Trade enregistré.', 'success');
  };

  return (
    <div>
      <BlobHeader title="Dashboard" subtitle="Marchés en temps réel · Conseil du jour · Progression de ton capital" />
      <div className="mx-auto -mt-8 flex max-w-xl flex-col gap-4 px-4">
        <Card>
          <SectionTitle eyebrow="Sessions live" title="Marchés en temps réel" subtitle="Mise à jour automatique toutes les 60 secondes" />
          <div className="grid grid-cols-2 gap-3">
            {marketStatuses.map((market) => (
              <div key={market.name} className={`rounded-3xl border p-4 ${market.isOpen ? 'border-emerald-200 bg-emerald-50' : 'border-slate-200 bg-slate-50'}`}>
                <div className="flex items-center justify-between gap-2">
                  <div className="text-lg font-bold">{market.flag} {market.name}</div>
                  <div className={`flex items-center gap-2 text-xs font-semibold ${market.isOpen ? 'text-emerald-700' : 'text-rose-600'}`}>
                    <span className={`h-2.5 w-2.5 rounded-full ${market.isOpen ? 'animate-pulse bg-emerald-500' : 'bg-rose-500'}`} />
                    {market.isOpen ? 'OUVERT' : 'FERMÉ'}
                  </div>
                </div>
                <p className="mt-3 text-sm text-slate-600">{market.timeLabel}</p>
                <p className="mt-2 text-xs text-slate-500">{market.pairs.join(' · ')}</p>
              </div>
            ))}
          </div>
          {overlap && <div className="mt-4 rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm font-semibold text-amber-800">🔥 OVERLAP LONDRES + NEW YORK · Maximum de liquidité · Meilleur moment pour trader</div>}
        </Card>

        <Card>
          <SectionTitle eyebrow="Conseil IA" title="Conseil SYNOX du jour" />
          <div className="rounded-2xl bg-synox-50 p-4 text-sm leading-relaxed text-slate-700">
            {adviceLoading ? (
              <div className="flex items-center gap-2 text-synox-700">
                <LoaderCircle className="h-4 w-4 animate-spin" /> Génération du conseil du jour...
              </div>
            ) : (
              dailyAdvice || 'Le conseil apparaîtra ici.'
            )}
          </div>
        </Card>

        <Card>
          <SectionTitle eyebrow="Progression manuelle" title="Enregistre un trade" subtitle="SYNOX adapte sa lecture selon tes résultats" />
          <div className="grid grid-cols-1 gap-3">
            <div>
              <label className="synox-label">Date</label>
              <input type="date" className="synox-input" value={form.date} onChange={(event) => setForm((prev) => ({ ...prev, date: event.target.value }))} />
            </div>
            <div>
              <label className="synox-label">Paire</label>
              <select className="synox-input" value={form.pair} onChange={(event) => setForm((prev) => ({ ...prev, pair: event.target.value }))}>
                {PAIRS.map((pair) => <option key={pair}>{pair}</option>)}
              </select>
            </div>
            <div>
              <label className="synox-label">Direction</label>
              <div className="grid grid-cols-2 gap-3">
                {['BUY', 'SELL'].map((direction) => (
                  <button
                    key={direction}
                    className={`rounded-2xl border px-4 py-3 text-sm font-bold ${form.direction === direction ? direction === 'BUY' ? 'border-emerald-300 bg-emerald-50 text-emerald-700' : 'border-rose-300 bg-rose-50 text-rose-700' : 'border-slate-200 bg-white text-slate-500'}`}
                    onClick={() => setForm((prev) => ({ ...prev, direction }))}
                  >
                    {direction}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <label className="synox-label">Résultat $</label>
              <input type="number" className="synox-input" placeholder="positif = gain, négatif = perte" value={form.result} onChange={(event) => setForm((prev) => ({ ...prev, result: event.target.value }))} />
            </div>
            <div>
              <label className="synox-label">Notes</label>
              <textarea className="synox-input min-h-[96px]" placeholder="Optionnel" value={form.notes} onChange={(event) => setForm((prev) => ({ ...prev, notes: event.target.value }))} />
            </div>
            <button className="synox-button w-full" onClick={submitTrade}>Enregistrer</button>
          </div>
          <div className="mt-4 rounded-2xl bg-slate-50 p-4 text-sm font-semibold text-slate-700">{getProgressionMessage(stats.winRate)}</div>
        </Card>

        <div className="grid grid-cols-2 gap-3">
          <MetricCard label="Capital actuel" value={formatMoney(currentCapital)} tone="purple" icon={<Wallet className="h-5 w-5 text-synox-600" />} />
          <MetricCard label="P&L net" value={formatMoney(stats.netPnL)} tone={stats.netPnL >= 0 ? 'green' : 'red'} icon={<TrendingUp className="h-5 w-5" />} />
          <MetricCard label="Win rate" value={`${formatNumber(stats.winRate)}%`} tone="neutral" icon={<BarChart3 className="h-5 w-5 text-slate-500" />} />
          <MetricCard label="Nb trades" value={String(stats.total)} tone="neutral" icon={<BookOpenText className="h-5 w-5 text-slate-500" />} />
        </div>

        <Card>
          <SectionTitle eyebrow="Équity curve" title="Évolution du capital" />
          <div className="h-60">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={capitalSeries}>
                <defs>
                  <linearGradient id="capitalGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#7C3AED" stopOpacity={0.32} />
                    <stop offset="95%" stopColor="#7C3AED" stopOpacity={0.03} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
                <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} width={54} />
                <Tooltip content={<CustomTooltip />} />
                <Area type="monotone" dataKey="capital" stroke="#7C3AED" strokeWidth={3} fill="url(#capitalGradient)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </Card>
      </div>
      <FooterDisclaimer />
    </div>
  );
}
