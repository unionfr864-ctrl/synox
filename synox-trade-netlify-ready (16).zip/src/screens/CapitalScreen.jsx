import { useMemo, useState } from 'react';
import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { computeDrawdown, formatMoney, formatNumber, getAdaptationMessage, getCapitalSeries, getCurrentCapital, lotCalculator, todayInputValue, uid } from '../lib/utils';
import { BlobHeader, Card, CustomTooltip, FooterDisclaimer, SectionTitle } from '../components/common';
import { PAIRS } from '../lib/constants';

export default function CapitalScreen({ state, onAddDeposit, showToast }) {
  const [flow, setFlow] = useState({ date: todayInputValue(), amount: '', note: '' });
  const [calc, setCalc] = useState({ riskPct: 1, slPips: 20, pair: 'EUR/USD' });

  const currentCapital = useMemo(() => getCurrentCapital(state), [state]);
  const capitalSeries = useMemo(() => getCapitalSeries(state), [state]);
  const drawdown = useMemo(() => computeDrawdown(capitalSeries), [capitalSeries]);
  const target = Math.max(Number(state.capital || 0) * 10, Number(currentCapital || 0));
  const progress = target ? Math.min(100, (currentCapital / target) * 100) : 0;
  const recommendedLot = useMemo(() => lotCalculator(currentCapital, calc.riskPct, calc.slPips, calc.pair), [currentCapital, calc]);
  const orderedFlows = useMemo(() => [...(state.deposits || [])].sort((a, b) => new Date(b.date) - new Date(a.date)), [state.deposits]);

  const submitFlow = () => {
    const amount = Number(flow.amount);
    if (Number.isNaN(amount) || amount === 0) {
      showToast('Entre un montant de dépôt ou retrait valide.');
      return;
    }
    onAddDeposit({ id: uid(), date: flow.date, amount, note: flow.note });
    setFlow({ date: todayInputValue(), amount: '', note: '' });
    showToast('Flux de capital enregistré.', 'success');
  };

  return (
    <div>
      <BlobHeader title="Capital" subtitle="Suivi du capital, drawdown, objectif et calculateur de taille de lot." />
      <div className="mx-auto -mt-8 flex max-w-xl flex-col gap-4 px-4">
        <Card className={`p-6 ${currentCapital >= state.capital ? 'bg-gradient-to-br from-emerald-50 to-white' : 'bg-gradient-to-br from-rose-50 to-white'}`}>
          <p className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-500">Capital actuel</p>
          <div className={`mt-3 font-display text-4xl font-black ${currentCapital >= state.capital ? 'text-emerald-700' : 'text-rose-700'}`}>{formatMoney(currentCapital)}</div>
          <p className="mt-2 text-sm text-slate-500">Capital initial : {formatMoney(state.capital)}</p>
        </Card>

        {drawdown > 20 && <div className="animate-pulse rounded-3xl border border-rose-300 bg-rose-50 p-4 text-sm font-bold text-rose-700">🚨 SYNOX dit STOP. Drawdown critique. Arrête de trader aujourd’hui.</div>}

        <Card>
          <SectionTitle eyebrow="Objectif" title="Progression vers x10" subtitle={`Objectif dynamique : ${formatMoney(target)}`} />
          <div className="h-4 overflow-hidden rounded-full bg-slate-100"><div className="h-full rounded-full bg-gradient-to-r from-synox-500 to-synox-700" style={{ width: `${progress}%` }} /></div>
          <p className="mt-3 text-sm text-slate-500">{formatNumber(progress)}% de l’objectif atteint</p>
        </Card>

        <Card>
          <SectionTitle eyebrow="Lot calculator" title="Calculateur de lot" />
          <div className="grid grid-cols-1 gap-3">
            <div className="grid grid-cols-3 gap-3">
              <div><label className="synox-label">Risque %</label><input type="number" className="synox-input" value={calc.riskPct} onChange={(event) => setCalc((prev) => ({ ...prev, riskPct: Number(event.target.value) }))} /></div>
              <div><label className="synox-label">SL pips</label><input type="number" className="synox-input" value={calc.slPips} onChange={(event) => setCalc((prev) => ({ ...prev, slPips: Number(event.target.value) }))} /></div>
              <div><label className="synox-label">Paire</label><select className="synox-input" value={calc.pair} onChange={(event) => setCalc((prev) => ({ ...prev, pair: event.target.value }))}>{PAIRS.map((pair) => <option key={pair}>{pair}</option>)}</select></div>
            </div>
            <div className="rounded-2xl bg-synox-50 p-4 text-sm text-slate-700">Taille recommandée : <span className="font-display text-xl font-black text-synox-700">{recommendedLot}</span> lot</div>
          </div>
        </Card>

        <Card>
          <SectionTitle eyebrow="Historique flux" title="Dépôts / retraits" />
          <div className="grid grid-cols-1 gap-3">
            <div className="grid grid-cols-2 gap-3">
              <div><label className="synox-label">Date</label><input type="date" className="synox-input" value={flow.date} onChange={(event) => setFlow((prev) => ({ ...prev, date: event.target.value }))} /></div>
              <div><label className="synox-label">Montant</label><input type="number" className="synox-input" placeholder="positif = dépôt, négatif = retrait" value={flow.amount} onChange={(event) => setFlow((prev) => ({ ...prev, amount: event.target.value }))} /></div>
            </div>
            <div><label className="synox-label">Note</label><input className="synox-input" value={flow.note} onChange={(event) => setFlow((prev) => ({ ...prev, note: event.target.value }))} /></div>
            <button className="synox-button w-full" onClick={submitFlow}>Enregistrer le flux</button>
          </div>
          <div className="mt-4 space-y-2">
            {orderedFlows.length === 0 && <div className="rounded-2xl bg-slate-50 p-4 text-sm text-slate-500">Aucun dépôt ou retrait enregistré.</div>}
            {orderedFlows.map((item) => (
              <div key={item.id} className="flex items-center justify-between rounded-2xl bg-slate-50 p-3 text-sm">
                <div>
                  <div className="font-semibold text-slate-900">{item.note || 'Flux de capital'}</div>
                  <div className="text-xs text-slate-500">{item.date}</div>
                </div>
                <div className={`font-bold ${Number(item.amount) >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>{formatMoney(item.amount)}</div>
              </div>
            ))}
          </div>
        </Card>

        <Card>
          <SectionTitle eyebrow="Évolution" title="Courbe de capital" />
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={capitalSeries}>
                <defs>
                  <linearGradient id="capitalTrack" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#7C3AED" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#7C3AED" stopOpacity={0.03} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
                <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} width={54} />
                <Tooltip content={<CustomTooltip />} />
                <Area type="monotone" dataKey="capital" stroke="#7C3AED" strokeWidth={3} fill="url(#capitalTrack)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card className="bg-slate-50">
          <SectionTitle eyebrow="Adaptation SYNOX" title="Lecture des 5 derniers trades" />
          <p className="text-sm text-slate-700">{getAdaptationMessage(state.trades)}</p>
        </Card>
      </div>
      <FooterDisclaimer />
    </div>
  );
}
