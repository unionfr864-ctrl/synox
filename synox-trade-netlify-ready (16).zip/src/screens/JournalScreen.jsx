import { useMemo, useState } from 'react';
import { Bar, BarChart, CartesianGrid, Cell, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { BadgeDollarSign, BarChart3, Sparkles, Trash2, TrendingUp } from 'lucide-react';
import { PAIRS } from '../lib/constants';
import { cn, computeTradeStats, formatMoney, formatNumber, todayInputValue, uid } from '../lib/utils';
import { BlobHeader, Card, FooterDisclaimer, MetricCard, SectionTitle } from '../components/common';

export default function JournalScreen({ trades, onAddTrade, onDeleteTrade, showToast }) {
  const [form, setForm] = useState({
    pair: 'EUR/USD',
    direction: 'BUY',
    lot: '0.01',
    entry: '',
    tp: '',
    sl: '',
    result: '',
    date: todayInputValue(),
    notes: '',
    rr: '',
  });

  const stats = useMemo(() => computeTradeStats(trades), [trades]);
  const pairResults = useMemo(() => {
    const map = trades.reduce((acc, trade) => {
      acc[trade.pair] = (acc[trade.pair] || 0) + Number(trade.result || 0);
      return acc;
    }, {});
    return Object.entries(map).map(([pair, value]) => ({ pair, value }));
  }, [trades]);
  const orderedTrades = useMemo(() => [...trades].sort((a, b) => new Date(b.date) - new Date(a.date)), [trades]);

  const submitTrade = () => {
    if (Number.isNaN(Number(form.result)) || !form.pair) {
      showToast('Complète au minimum la paire et le résultat.');
      return;
    }

    onAddTrade({ id: uid(), ...form, result: Number(form.result) });
    setForm({ pair: form.pair, direction: form.direction, lot: form.lot, entry: '', tp: '', sl: '', result: '', date: todayInputValue(), notes: '', rr: '' });
    showToast('Trade ajouté au journal.', 'success');
  };

  return (
    <div>
      <BlobHeader title="Journal" subtitle="Historique complet des trades, statistiques automatiques et résultats par paire." />
      <div className="mx-auto -mt-8 flex max-w-xl flex-col gap-4 px-4">
        <Card>
          <SectionTitle eyebrow="Ajout manuel" title="Nouveau trade" />
          <div className="grid grid-cols-1 gap-3">
            <div>
              <label className="synox-label">Paire</label>
              <select className="synox-input" value={form.pair} onChange={(event) => setForm((prev) => ({ ...prev, pair: event.target.value }))}>
                {PAIRS.map((pair) => <option key={pair}>{pair}</option>)}
              </select>
            </div>
            <div>
              <label className="synox-label">Direction</label>
              <div className="grid grid-cols-2 gap-3">
                {['BUY', 'SELL'].map((direction) => (
                  <button
                    key={direction}
                    className={cn(
                      'rounded-2xl border px-4 py-3 text-sm font-bold',
                      form.direction === direction
                        ? direction === 'BUY' ? 'border-emerald-300 bg-emerald-50 text-emerald-700' : 'border-rose-300 bg-rose-50 text-rose-700'
                        : 'border-slate-200 bg-white text-slate-500',
                    )}
                    onClick={() => setForm((prev) => ({ ...prev, direction }))}
                  >
                    {direction}
                  </button>
                ))}
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><label className="synox-label">Lot size</label><input className="synox-input" value={form.lot} onChange={(event) => setForm((prev) => ({ ...prev, lot: event.target.value }))} /></div>
              <div><label className="synox-label">Date</label><input type="date" className="synox-input" value={form.date} onChange={(event) => setForm((prev) => ({ ...prev, date: event.target.value }))} /></div>
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div><label className="synox-label">Entrée</label><input className="synox-input" value={form.entry} onChange={(event) => setForm((prev) => ({ ...prev, entry: event.target.value }))} /></div>
              <div><label className="synox-label">TP</label><input className="synox-input" value={form.tp} onChange={(event) => setForm((prev) => ({ ...prev, tp: event.target.value }))} /></div>
              <div><label className="synox-label">SL</label><input className="synox-input" value={form.sl} onChange={(event) => setForm((prev) => ({ ...prev, sl: event.target.value }))} /></div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><label className="synox-label">Résultat $</label><input type="number" className="synox-input" value={form.result} onChange={(event) => setForm((prev) => ({ ...prev, result: event.target.value }))} /></div>
              <div><label className="synox-label">R/R</label><input className="synox-input" placeholder="ex : 1:2.5" value={form.rr} onChange={(event) => setForm((prev) => ({ ...prev, rr: event.target.value }))} /></div>
            </div>
            <div>
              <label className="synox-label">Notes</label>
              <textarea className="synox-input min-h-[90px]" value={form.notes} onChange={(event) => setForm((prev) => ({ ...prev, notes: event.target.value }))} />
            </div>
            <button className="synox-button w-full" onClick={submitTrade}>Ajouter au journal</button>
          </div>
        </Card>

        <div className="grid grid-cols-2 gap-3">
          <MetricCard label="Win rate" value={`${formatNumber(stats.winRate)}%`} tone="purple" icon={<TrendingUp className="h-5 w-5 text-synox-600" />} />
          <MetricCard label="P&L net" value={formatMoney(stats.netPnL)} tone={stats.netPnL >= 0 ? 'green' : 'red'} icon={<BadgeDollarSign className="h-5 w-5" />} />
          <MetricCard label="Profit factor" value={formatNumber(stats.profitFactor)} tone="neutral" icon={<BarChart3 className="h-5 w-5 text-slate-500" />} />
          <MetricCard label="Win streak" value={String(stats.winStreak)} tone="neutral" icon={<Sparkles className="h-5 w-5 text-slate-500" />} />
        </div>

        <Card>
          <SectionTitle eyebrow="Stats avancées" title="Résumé automatique" />
          <div className="grid grid-cols-2 gap-3 text-sm">
            <div className="rounded-2xl bg-slate-50 p-4"><div className="text-xs uppercase tracking-[0.16em] text-slate-500">Total gains</div><div className="mt-2 font-bold text-emerald-700">{formatMoney(stats.totalGain)}</div></div>
            <div className="rounded-2xl bg-slate-50 p-4"><div className="text-xs uppercase tracking-[0.16em] text-slate-500">Total pertes</div><div className="mt-2 font-bold text-rose-700">{formatMoney(stats.totalLoss)}</div></div>
            <div className="rounded-2xl bg-slate-50 p-4"><div className="text-xs uppercase tracking-[0.16em] text-slate-500">Meilleure paire</div><div className="mt-2 font-bold text-slate-900">{stats.bestPair}</div></div>
            <div className="rounded-2xl bg-slate-50 p-4"><div className="text-xs uppercase tracking-[0.16em] text-slate-500">Paire à surveiller</div><div className="mt-2 font-bold text-slate-900">{stats.worstPair}</div></div>
            <div className="rounded-2xl bg-slate-50 p-4"><div className="text-xs uppercase tracking-[0.16em] text-slate-500">Trades</div><div className="mt-2 font-bold text-slate-900">{stats.total}</div></div>
            <div className="rounded-2xl bg-slate-50 p-4"><div className="text-xs uppercase tracking-[0.16em] text-slate-500">R/R moyen</div><div className="mt-2 font-bold text-slate-900">{formatNumber(stats.avgRR)}</div></div>
          </div>
        </Card>

        <Card>
          <SectionTitle eyebrow="Par paire" title="Résultats" />
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={pairResults}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
                <XAxis dataKey="pair" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip formatter={(value) => formatMoney(value)} />
                <Bar dataKey="value" radius={[10, 10, 0, 0]}>
                  {pairResults.map((entry) => <Cell key={entry.pair} fill={entry.value >= 0 ? '#10B981' : '#EF4444'} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card>
          <SectionTitle eyebrow="Historique" title="Trades enregistrés" />
          <div className="space-y-3">
            {orderedTrades.length === 0 && <div className="rounded-2xl bg-slate-50 p-4 text-sm text-slate-500">Aucun trade enregistré pour le moment.</div>}
            {orderedTrades.map((trade) => (
              <div key={trade.id} className="flex items-start gap-3 rounded-2xl border border-slate-100 bg-white p-4 shadow-soft">
                <div className={cn('mt-1 rounded-full px-2 py-1 text-[11px] font-bold', trade.direction === 'BUY' ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700')}>
                  {trade.direction}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
                    <span className="font-semibold text-slate-900">{trade.pair}</span>
                    <span className="text-xs text-slate-500">{trade.date}</span>
                    {trade.lot && <span className="text-xs text-slate-500">Lot {trade.lot}</span>}
                  </div>
                  <div className="mt-1 text-sm text-slate-500">{trade.notes || 'Aucune note.'}</div>
                </div>
                <div className="flex items-center gap-2">
                  <div className={cn('text-sm font-bold', Number(trade.result) >= 0 ? 'text-emerald-600' : 'text-rose-600')}>{formatMoney(trade.result)}</div>
                  <button onClick={() => onDeleteTrade(trade.id)} className="rounded-xl bg-slate-100 p-2 text-slate-500 transition hover:bg-rose-50 hover:text-rose-600">
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>
      <FooterDisclaimer />
    </div>
  );
}
