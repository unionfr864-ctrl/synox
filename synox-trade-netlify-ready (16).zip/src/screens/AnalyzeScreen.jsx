import { useEffect, useRef, useState } from 'react';
import { Camera, LoaderCircle, Upload } from 'lucide-react';
import { LOADING_MSGS, PAIRS, TIMEFRAMES } from '../lib/constants';
import { analyzeChart } from '../lib/api';
import { Badge, BlobHeader, Card, FooterDisclaimer, SectionTitle } from '../components/common';

function AnalyzeResult({ result }) {
  if (!result) return null;

  const cal = result.synox_calibration || {};
  const time = result.algorithmic_time || {};
  const liq = result.liquidity_map || {};
  const macro = result.macro_pulse || {};
  const exec = result.execution_matrix || {};
  const setup = exec.order_setup || {};

  const score = Number(exec.confluence_score || 0);
  const scoreColor = score >= 85 ? '#10B981' : score >= 60 ? '#F59E0B' : '#EF4444';
  const scoreLabel = score >= 85 ? 'SIGNAL VALIDÉ ✅' : score >= 60 ? 'SURVEILLANCE 👁' : 'SIGNAL BLOQUÉ ❌';
  const isBuy = setup.direction === 'BUY';

  return (
    <div className="mt-4 flex flex-col gap-4">
      <div className={`rounded-3xl border p-4 ${cal.calibration_status === 'SUCCESS' ? 'border-emerald-200 bg-emerald-50' : 'border-rose-200 bg-rose-50'}`}>
        <div className={`text-xs font-bold uppercase tracking-[0.18em] ${cal.calibration_status === 'SUCCESS' ? 'text-emerald-700' : 'text-rose-700'}`}>
          {cal.calibration_status === 'SUCCESS' ? '✅ Calibration OK' : '❌ Calibration failed'}
        </div>
        <p className="mt-2 text-sm font-semibold text-slate-900">
          {cal.pair || 'Actif non identifié'} · {cal.timeframe || 'TF inconnu'} · Prix détecté : {cal.detected_price || '—'}
        </p>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <Card className="bg-synox-50">
          <p className="text-[11px] font-bold uppercase tracking-[0.16em] text-slate-500">Killzone GMT</p>
          <p className="mt-2 text-sm font-bold text-synox-700">{time.active_killzone === 'NONE' ? '⛔ Hors killzone' : `⚡ ${time.active_killzone || '—'}`}</p>
          <p className="mt-1 text-xs text-slate-500">{time.current_gmt_time || '—'} GMT</p>
        </Card>
        <Card className="bg-synox-50">
          <p className="text-[11px] font-bold uppercase tracking-[0.16em] text-slate-500">Phase marché</p>
          <p className="mt-2 text-sm font-bold text-synox-700">{time.market_state || '—'}</p>
        </Card>
      </div>

      <div className="rounded-3xl border-2 p-4" style={{ borderColor: scoreColor, backgroundColor: `${scoreColor}12` }}>
        <div className="flex items-center gap-4">
          <div className="font-display text-4xl font-black" style={{ color: scoreColor }}>{score}</div>
          <div>
            <p className="text-sm font-bold" style={{ color: scoreColor }}>{scoreLabel}</p>
            <p className="text-xs text-slate-500">Score Matrice SCM / 100</p>
            {exec.blocking_reason && <p className="mt-2 text-xs text-rose-600">⚠️ {exec.blocking_reason}</p>}
          </div>
        </div>
      </div>

      {exec.decision === 'VALIDATED' && (
        <div className={`rounded-[28px] border-2 p-5 ${isBuy ? 'border-emerald-300 bg-gradient-to-br from-emerald-50 to-white' : 'border-rose-300 bg-gradient-to-br from-rose-50 to-white'}`}>
          <div className="mb-4 flex items-center gap-3">
            <div className={`font-display text-3xl font-black ${isBuy ? 'text-emerald-600' : 'text-rose-600'}`}>{isBuy ? '🟢 BUY' : '🔴 SELL'}</div>
            <div className="ml-auto rounded-full bg-white px-3 py-1 text-xs font-bold text-slate-600 shadow-soft">Score {score}/100</div>
          </div>
          <div className="grid grid-cols-3 gap-3">
            <Card className="bg-white/70 text-center"><div className="text-[11px] uppercase tracking-[0.14em] text-slate-400">Entrée</div><div className="mt-2 text-sm font-bold">{setup.entry_zone || '—'}</div></Card>
            <Card className="bg-white/70 text-center"><div className="text-[11px] uppercase tracking-[0.14em] text-slate-400">TP1</div><div className="mt-2 text-sm font-bold text-emerald-600">{setup.take_profit_1 || '—'}</div></Card>
            <Card className="bg-white/70 text-center"><div className="text-[11px] uppercase tracking-[0.14em] text-slate-400">SL</div><div className="mt-2 text-sm font-bold text-rose-600">{setup.stop_loss || '—'}</div></Card>
          </div>
          <div className="mt-3 grid grid-cols-2 gap-3">
            <Card className="bg-white/70 text-center"><div className="text-[11px] uppercase tracking-[0.14em] text-slate-400">TP2</div><div className="mt-2 text-sm font-bold text-emerald-600">{setup.take_profit_2 || '—'}</div></Card>
            <Card className="bg-white/70 text-center"><div className="text-[11px] uppercase tracking-[0.14em] text-slate-400">Ratio R/R</div><div className="mt-2 font-display text-lg font-black text-synox-700">{setup.risk_reward_ratio || '—'}</div></Card>
          </div>
        </div>
      )}

      {exec.decision === 'MONITORING' && <div className="rounded-3xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-800"><div className="font-bold">👁 Configuration en formation</div><p className="mt-2">{exec.blocking_reason || 'Confluence encore insuffisante.'}</p></div>}
      {exec.decision === 'BLOCKED' && <div className="rounded-3xl border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700"><div className="font-bold">⛔ Signal bloqué</div><p className="mt-2">{exec.blocking_reason || 'Le moteur SYNOX recommande de ne pas prendre position.'}</p></div>}

      <Card className="bg-gradient-to-br from-synox-50 to-white">
        <p className="text-[11px] font-bold uppercase tracking-[0.18em] text-synox-700">🗺️ Carte liquidité institutionnelle</p>
        <div className="mt-4 space-y-3 text-sm">
          <div className="flex items-center justify-between gap-3 border-b border-synox-100 pb-3">
            <span className="text-slate-500">Order Flow</span>
            <span className={`font-bold ${liq.institutional_order_flow === 'BULLISH' ? 'text-emerald-600' : 'text-rose-600'}`}>{liq.institutional_order_flow || '—'}</span>
          </div>
          <div className="border-b border-synox-100 pb-3">
            <div className="text-slate-500">Dernier Stop-Hunt</div>
            <div className="mt-1 font-semibold text-slate-900">{liq.last_liquidity_swept || '—'}</div>
          </div>
          <div>
            <div className="text-slate-500">Prochain target institutionnel</div>
            <div className="mt-1 font-semibold text-synox-700">🎯 {liq.next_liquidity_target || '—'}</div>
          </div>
        </div>
      </Card>

      <Card className="border-amber-100 bg-amber-50">
        <p className="text-[11px] font-bold uppercase tracking-[0.18em] text-amber-700">📡 Macro pulse · Mis à jour {macro.last_web_update || '—'} GMT</p>
        {macro.high_impact_event_alert && <p className="mt-3 text-sm font-semibold text-amber-900">⚠️ {macro.high_impact_event_alert}</p>}
        <p className="mt-2 text-sm text-amber-900/90">{macro.deviation_analysis || 'Aucune précision macro transmise.'}</p>
      </Card>

      {(result.other_pairs || []).length > 0 && (
        <Card>
          <SectionTitle eyebrow="Autres opportunités" title="Paires détectées par SYNOX" />
          <div className="space-y-2">
            {result.other_pairs.map((pair, index) => (
              <div key={`${pair.pair}-${index}`} className="flex items-center gap-3 rounded-2xl bg-slate-50 p-3">
                <Badge color={pair.direction === 'BUY' ? 'green' : 'red'}>{pair.direction}</Badge>
                <div className="min-w-0 flex-1">
                  <div className="font-semibold text-slate-900">{pair.pair}</div>
                  <div className="text-xs text-slate-500">{pair.reason}</div>
                </div>
                <div className="text-right">
                  <div className="text-sm font-bold text-synox-700">{pair.score}/100</div>
                  <div className="text-[11px] text-slate-500">{pair.timing}</div>
                </div>
              </div>
            ))}
          </div>
        </Card>
      )}

      <div className="rounded-3xl border-l-4 border-synox-600 bg-gradient-to-br from-synox-50 to-white p-4">
        <p className="text-[11px] font-bold uppercase tracking-[0.18em] text-synox-700">⚡ Verdict SYNOX TRADE™</p>
        <p className="mt-3 text-sm font-semibold italic text-slate-900">“{result.verdict || 'Verdict indisponible.'}”</p>
      </div>
    </div>
  );
}

export default function AnalyzeScreen({ showToast }) {
  const fileRef = useRef(null);
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState('');
  const [pair, setPair] = useState('');
  const [timeframe, setTimeframe] = useState('');
  const [loading, setLoading] = useState(false);
  const [loadingIndex, setLoadingIndex] = useState(0);
  const [result, setResult] = useState(null);

  useEffect(() => {
    if (!loading) return undefined;
    const timer = setInterval(() => setLoadingIndex((prev) => (prev + 1) % LOADING_MSGS.length), 2000);
    return () => clearInterval(timer);
  }, [loading]);

  useEffect(() => () => {
    if (preview) URL.revokeObjectURL(preview);
  }, [preview]);

  const handleFileChange = (event) => {
    const selected = event.target.files?.[0];
    if (!selected) return;
    if (preview) URL.revokeObjectURL(preview);
    setFile(selected);
    setPreview(URL.createObjectURL(selected));
    setResult(null);
  };

  const toBase64 = (targetFile) => new Promise((resolve) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result).split(',')[1]);
    reader.readAsDataURL(targetFile);
  });

  const runAnalysis = async () => {
    if (!file) {
      showToast('Ajoute un screenshot MT4 avant de lancer l’analyse.');
      return;
    }

    setLoading(true);
    setLoadingIndex(0);
    setResult(null);
    try {
      const imageBase64 = await toBase64(file);
      const analysis = await analyzeChart({ imageBase64, mediaType: file.type || 'image/jpeg', pair, timeframe });
      setResult(analysis);
      showToast('Analyse terminée.', 'success');
    } catch (error) {
      showToast(error.message || 'Erreur d’analyse. Réessaie avec une image plus nette.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <BlobHeader title="Analyser" subtitle="Upload ton screenshot MT4 et laisse SYNOX cartographier structure, liquidité et killzones." />
      <div className="mx-auto -mt-8 flex max-w-xl flex-col gap-4 px-4">
        <Card>
          <SectionTitle eyebrow="Étape 1" title="Upload screenshot MT4" subtitle="N’importe quelle paire · N’importe quel timeframe" />
          <div onClick={() => fileRef.current?.click()} className="cursor-pointer rounded-[24px] border-2 border-dashed border-synox-300 bg-synox-50 p-7 text-center transition hover:border-synox-400">
            <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={handleFileChange} />
            {preview ? (
              <img src={preview} alt="Aperçu du graphique" className="mx-auto max-h-[220px] max-w-full rounded-2xl object-contain shadow-soft" />
            ) : (
              <>
                <div className="mx-auto mb-3 flex h-16 w-16 items-center justify-center rounded-2xl bg-white text-synox-700 shadow-soft"><Camera className="h-8 w-8" /></div>
                <div className="text-lg font-bold text-slate-900">Upload screenshot MT4</div>
                <div className="mt-1 text-sm text-slate-500">Analyse instantanée de la structure du marché</div>
              </>
            )}
          </div>

          <div className="mt-4 grid grid-cols-2 gap-3">
            <div>
              <label className="synox-label">Paire (optionnel)</label>
              <select className="synox-input" value={pair} onChange={(event) => setPair(event.target.value)}>
                <option value="">Auto-détection</option>
                {PAIRS.map((value) => <option key={value}>{value}</option>)}
              </select>
            </div>
            <div>
              <label className="synox-label">Timeframe (optionnel)</label>
              <select className="synox-input" value={timeframe} onChange={(event) => setTimeframe(event.target.value)}>
                <option value="">Auto-détection</option>
                {TIMEFRAMES.map((value) => <option key={value}>{value}</option>)}
              </select>
            </div>
          </div>

          <button className="synox-button mt-4 w-full" onClick={runAnalysis} disabled={loading}>
            {loading ? <LoaderCircle className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />}
            Analyser avec SYNOX
          </button>
        </Card>

        {loading && (
          <Card>
            <SectionTitle eyebrow="Analyse en cours" title="Moteur institutionnel actif" />
            <div className="flex items-center gap-3 rounded-2xl bg-synox-50 p-4 text-sm font-semibold text-synox-700">
              <LoaderCircle className="h-5 w-5 animate-spin" />
              {LOADING_MSGS[loadingIndex]}
            </div>
          </Card>
        )}

        <AnalyzeResult result={result} />
      </div>
      <FooterDisclaimer />
    </div>
  );
}
