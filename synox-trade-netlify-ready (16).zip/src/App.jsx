import { useEffect, useRef, useState } from 'react';
import { ArrowRight, CalendarDays, Globe2, Landmark, TrendingUp } from 'lucide-react';
import { INSTALL_CACHE_KEY, STORAGE_KEY, defaultState } from './lib/constants';
import { uid } from './lib/utils';
import { BottomNav, InstallBanner, Toast } from './components/common';
import OnboardingScreen from './screens/OnboardingScreen';
import HomeScreen from './screens/HomeScreen';
import AnalyzeScreen from './screens/AnalyzeScreen';
import JournalScreen from './screens/JournalScreen';
import CapitalScreen from './screens/CapitalScreen';
import SignalsScreen from './screens/SignalsScreen';

const WelcomeStrip = () => (
  <div className="mx-4 mt-4 grid grid-cols-3 gap-3">
    <div className="rounded-3xl bg-white/90 p-4 shadow-soft">
      <div className="mb-2 flex h-10 w-10 items-center justify-center rounded-2xl bg-synox-100 text-synox-700"><TrendingUp className="h-5 w-5" /></div>
      <div className="text-xs font-bold uppercase tracking-[0.14em] text-slate-500">SMC + ICT</div>
      <div className="mt-1 text-sm font-semibold text-slate-900">Lecture institutionnelle</div>
    </div>
    <div className="rounded-3xl bg-white/90 p-4 shadow-soft">
      <div className="mb-2 flex h-10 w-10 items-center justify-center rounded-2xl bg-synox-100 text-synox-700"><Landmark className="h-5 w-5" /></div>
      <div className="text-xs font-bold uppercase tracking-[0.14em] text-slate-500">Macro</div>
      <div className="mt-1 text-sm font-semibold text-slate-900">Fed, BCE, DXY, news</div>
    </div>
    <div className="rounded-3xl bg-white/90 p-4 shadow-soft">
      <div className="mb-2 flex h-10 w-10 items-center justify-center rounded-2xl bg-synox-100 text-synox-700"><CalendarDays className="h-5 w-5" /></div>
      <div className="text-xs font-bold uppercase tracking-[0.14em] text-slate-500">PWA</div>
      <div className="mt-1 text-sm font-semibold text-slate-900">Installable Android</div>
    </div>
  </div>
);

export default function App() {
  const [state, setState] = useState(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (!saved) return defaultState;
      return { ...defaultState, ...JSON.parse(saved) };
    } catch {
      return defaultState;
    }
  });
  const [toast, setToast] = useState(null);
  const [showInstall, setShowInstall] = useState(false);
  const deferredPromptRef = useRef(null);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  }, [state]);

  useEffect(() => {
    const dismissed = localStorage.getItem(INSTALL_CACHE_KEY);
    const handler = (event) => {
      event.preventDefault();
      deferredPromptRef.current = event;
      if (!dismissed) setShowInstall(true);
    };
    window.addEventListener('beforeinstallprompt', handler);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  useEffect(() => {
    if (!toast) return undefined;
    const timer = setTimeout(() => setToast(null), 5000);
    return () => clearTimeout(timer);
  }, [toast]);

  const showToast = (message, type = 'error') => setToast({ message, type, id: uid() });

  const patchState = (patch) => setState((prev) => ({ ...prev, ...patch }));
  const addTrade = (trade) => setState((prev) => ({ ...prev, trades: [...prev.trades, trade] }));
  const deleteTrade = (id) => setState((prev) => ({ ...prev, trades: prev.trades.filter((trade) => trade.id !== id) }));
  const addDeposit = (entry) => setState((prev) => ({ ...prev, deposits: [...prev.deposits, entry] }));

  const handleInstall = async () => {
    if (!deferredPromptRef.current) return;
    deferredPromptRef.current.prompt();
    await deferredPromptRef.current.userChoice.catch(() => null);
    deferredPromptRef.current = null;
    setShowInstall(false);
  };

  const dismissInstall = () => {
    localStorage.setItem(INSTALL_CACHE_KEY, '1');
    setShowInstall(false);
  };

  if (!state.isOnboarded) {
    return (
      <>
        <Toast toast={toast} onClose={() => setToast(null)} />
        <InstallBanner visible={showInstall} onInstall={handleInstall} onDismiss={dismissInstall} />
        <WelcomeStrip />
        <OnboardingScreen
          state={state}
          showToast={showToast}
          onProjectionSave={(capital, projection) => patchState({ capital, projection, projectionTimestamp: Date.now() })}
          onFinish={(capital) => patchState({ capital, isOnboarded: true, activeTab: 'home' })}
        />
      </>
    );
  }

  const renderActiveScreen = () => {
    switch (state.activeTab) {
      case 'home':
        return <HomeScreen state={state} onAddTrade={addTrade} showToast={showToast} />;
      case 'analyze':
        return <AnalyzeScreen showToast={showToast} />;
      case 'journal':
        return <JournalScreen trades={state.trades} onAddTrade={addTrade} onDeleteTrade={deleteTrade} showToast={showToast} />;
      case 'capital':
        return <CapitalScreen state={state} onAddDeposit={addDeposit} showToast={showToast} />;
      case 'signals':
        return <SignalsScreen state={state} showToast={showToast} onSignalsSave={(signals) => patchState({ lastSignals: signals, signalsTimestamp: Date.now() })} />;
      default:
        return <HomeScreen state={state} onAddTrade={addTrade} showToast={showToast} />;
    }
  };

  return (
    <div className="min-h-screen bg-[#F4F2FF] text-slate-900">
      <Toast toast={toast} onClose={() => setToast(null)} />
      <InstallBanner visible={showInstall} onInstall={handleInstall} onDismiss={dismissInstall} />

      <div className="mx-auto min-h-screen max-w-xl bg-transparent pb-28">
        <div className="mx-4 mt-4 flex items-center justify-between rounded-3xl bg-white/80 p-4 shadow-soft backdrop-blur">
          <div>
            <div className="text-[11px] font-bold uppercase tracking-[0.2em] text-synox-600">Station de trading</div>
            <div className="mt-1 text-sm text-slate-500">Application bâtie à partir du brief SYNOX</div>
          </div>
          <div className="flex items-center gap-2 rounded-full bg-synox-100 px-3 py-2 text-xs font-semibold text-synox-700">
            <Globe2 className="h-4 w-4" />
            Live + localStorage
          </div>
        </div>

        <div className="mt-3 rounded-3xl bg-white/80 px-4 py-3 shadow-soft mx-4 flex items-center justify-between">
          <div>
            <div className="text-sm font-semibold text-slate-900">Navigation active</div>
            <div className="text-xs text-slate-500">{state.activeTab}</div>
          </div>
          <button className="synox-button-secondary" onClick={() => patchState({ activeTab: 'signals' })}>
            Voir signaux <ArrowRight className="h-4 w-4" />
          </button>
        </div>

        {renderActiveScreen()}
      </div>

      <BottomNav activeTab={state.activeTab} onChange={(tab) => patchState({ activeTab: tab })} />
    </div>
  );
}
