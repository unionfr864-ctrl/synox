# SYNOX TRADE™

Application React inspirée du brief `SYNOX_ULTIMATE_V3-1.md`.

## Lancer le projet en local

### Option simple
```bash
npm install
npm run dev
```

### Option recommandée avec proxy Netlify local
```bash
npm install
npx netlify dev
```

## Variables d'environnement

Copiez `.env.example` vers `.env` puis renseignez votre clé Anthropic :

```bash
cp .env.example .env
```

Variables attendues :

```env
ANTHROPIC_API_KEY=...
ANTHROPIC_MODEL=claude-sonnet-4-20250514
```

## Déploiement Netlify

Le projet est prêt pour Netlify avec :
- `netlify.toml`
- une fonction serverless `netlify/functions/anthropic.js`
- un proxy front → `/api/anthropic`
- un fallback SPA

### Méthode la plus rapide
1. Pousse le dossier sur GitHub.
2. Dans Netlify : **Add new site** → **Import an existing project**.
3. Sélectionne le repo.
4. Netlify détectera automatiquement :
   - Build command : `npm run build`
   - Publish directory : `dist`
5. Dans **Site configuration** → **Environment variables**, ajoute :
   - `ANTHROPIC_API_KEY`
   - `ANTHROPIC_MODEL=claude-sonnet-4-20250514`
6. Lance le déploiement.

### Résultat
Tu obtiendras un lien du type :
- `https://nom-du-site.netlify.app`

## Important

- La clé API n'est **pas** embarquée dans le code front.
- Les appels Anthropic passent via la fonction Netlify.
- Le mode PWA est inclus avec `manifest.json` et un service worker minimal.
